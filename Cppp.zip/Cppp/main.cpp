#include <iostream>
#include "header.h"
#include <fstream>
#include <string>
#include <iostream>

using namespace std;


int main(){
    std::string hello;
    std::string name;
    //char *name, *hello;
    cout << "Enter Your Name: ";
    cin >> name;

    hello = Greeting();
    cout << ">>>" << hello << "  " << name << endl;

    return 0;
}
