char* Greeting(){
    //const char output[100] = "Hello ";
    return "Hello";
}
